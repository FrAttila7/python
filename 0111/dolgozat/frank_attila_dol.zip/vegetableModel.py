#Frank Attila, IFRA I N
#2022.01.11.


class VegetableModel:
    def __init__(self, id=0, name="nevtelen", quantity=0, price=0, site="ismeretlen"):
        self.id = id
        self.name = name
        self.quantity = quantity
        self.price = price
        self.site = site


