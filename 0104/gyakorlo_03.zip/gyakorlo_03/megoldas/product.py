class Product:
    def __init__(self, id=0, name='névtelen', price=0, weight=0):
        self.id = id
        self.name = name
        self.price = int(price)
        self.weight = int(weight)

